
# SPAACHAIN Core

This is the **bootstrap scaffolding** for the SPAACHAIN L1 node.
It compiles and runs a placeholder node with stubbed subsystems:

- P2P (placeholder)
- Mempool (placeholder)
- Consensus (placeholder)
- RPC (placeholder)
- Telemetry (placeholder)
- Crypto traits for SPHINCS+, Dilithium-5, Falcon

## Build & Run

```bash
cd core
cargo build
cargo run
```

You should see logs indicating subsystems are online.
