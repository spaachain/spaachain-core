
use anyhow::Result;

pub trait SignatureScheme {
    fn name(&self) -> &'static str;
    fn sign(&self, _msg: &[u8]) -> Result<Vec<u8>> {
        // TODO: implement algorithm
        Ok(vec![])
    }
    fn verify(&self, _msg: &[u8], _sig: &[u8]) -> Result<bool> {
        // TODO: implement algorithm
        Ok(true)
    }
}

pub struct Sphincs;
impl SignatureScheme for Sphincs {
    fn name(&self) -> &'static str { "SPHINCS+" }
}

pub struct Dilithium;
impl SignatureScheme for Dilithium {
    fn name(&self) -> &'static str { "Dilithium-5" }
}

pub struct Falcon;
impl SignatureScheme for Falcon {
    fn name(&self) -> &'static str { "Falcon" }
}
