
use anyhow::Result;

pub fn schedule_parallel(_txs: &[Vec<u8>]) -> Result<()> {
    // TODO: RW-set detection, conflict-free scheduling
    Ok(())
}
