
use anyhow::Result;
use tracing::{info, Level};
use tracing_subscriber::EnvFilter;

mod p2p;
mod consensus;
mod mempool;
mod crypto;
mod state;
mod exec;
mod vm;
mod rpc;
mod telemetry;

#[tokio::main]
async fn main() -> Result<()> {
    // logging
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env()
            .add_directive(Level::INFO.into()))
        .init();

    info!("🚀 SPAACHAIN node starting...");
    telemetry::init_metrics();

    // start subsystems (placeholders for now)
    p2p::start().await?;
    mempool::start().await?;
    consensus::start().await?;
    rpc::start().await?;

    info!("✅ SPAACHAIN node shutdown.");
    Ok(())
}
