
use anyhow::Result;
use tracing::info;

#[derive(Debug, Clone)]
pub struct Tx {
    pub bytes: Vec<u8>,
    // TODO: add sender, signature, nonce, gas, etc.
}

pub async fn start() -> Result<()> {
    // TODO: priority queue, encrypted mempool, fee market (EIP-1559 style)
    info!("🧳 Mempool subsystem online (placeholder)");
    Ok(())
}
