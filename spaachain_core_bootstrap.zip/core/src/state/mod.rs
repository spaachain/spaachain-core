
use anyhow::Result;

pub fn put(_key: &[u8], _val: &[u8]) -> Result<()> {
    // TODO: wire RocksDB/Sled, merkle/verkle trees
    Ok(())
}
