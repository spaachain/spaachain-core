
pub enum VmKind { Move, Wasm, Zk }

pub fn execute(_vm: VmKind, _bytecode: &[u8]) -> anyhow::Result<Vec<u8>> {
    // TODO: VM adapters
    Ok(Vec::new())
}
