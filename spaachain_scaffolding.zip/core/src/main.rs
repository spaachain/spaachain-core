fn main(){ println!("SPAACHAIN node placeholder"); }
