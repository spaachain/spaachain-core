#!/bin/bash
echo 'Localnet starting...'
