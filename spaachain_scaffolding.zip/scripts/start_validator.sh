#!/bin/bash
echo 'Validator starting...'
