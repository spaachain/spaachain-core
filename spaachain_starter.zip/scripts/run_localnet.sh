#!/bin/bash
echo 'Starting localnet...'
