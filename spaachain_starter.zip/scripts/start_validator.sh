#!/bin/bash
echo 'Starting validator...'
